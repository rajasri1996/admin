/**
=========================================================
* Soft UI Dashboard PRO React - v2.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/soft-ui-dashboard-pro-material-ui
* Copyright 2021 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// Soft UI Dashboard PRO React components
// import SuiBox from "components/SuiBox";
// import SuiBadgeDot from "components/SuiBadgeDot";

// Images
// import team1 from "assets/images/team-1.jpg";
// import team2 from "assets/images/team-2.jpg";
// import team3 from "assets/images/team-3.jpg";

export default {
  columns: [
    // { name: "name", align: "center" },
    { name: "function", align: "center" },
    // { name: "review", align: "left" },
    // { name: "email", align: "center" },
    { name: "employed", align: "left" },
    { name: "id", align: "left" },
  ],

  rows: [
    {
      function: "UTI Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot size="small" badgeContent="positive" />
      //   </SuiBox>
      // ),
      // email: "john@user.com",
      employed: "1,47,60,680",
      id: "1,72,54,672",
    },
    {
      function: "Nippon India Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot size="small" badgeContent="positive" />
      //   </SuiBox>
      // ),
      // email: "alexa@user.com",
      employed: "20,52,156",
      id: "24,28,133",
    },
    {
      // name: [team1, "Laurent Perrier"],
      function: "MIRAE Asset Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot color="dark" size="small" badgeContent="neutral" />
      //   </SuiBox>
      // ),
      // email: "laurent@user.com",
      employed: "9,15,997",
      id: "15,48,990",
    },
    {
      // name: [team3, "Michael Levi"],
      function: "Axis Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot size="small" badgeContent="positive" />
      //   </SuiBox>
      // ),
      // email: "michael@user.com",
      employed: "5,33,992",
      id: "8,15,321",
    },
    {
      // name: [team2, "Richard Gran"],
      function: "Canara Robeco Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot color="error" size="small" badgeContent="negative" />
      //   </SuiBox>
      // ),
      // email: "richard@user.com",
      employed: "2,22,489",
      id: "2,17,454",
    },
    {
      // name: [team3, "Miriam Eric"],
      function: "Quant Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot size="small" badgeContent="positive" />
      //   </SuiBox>
      // ),
      // email: "miriam@user.com",
      employed: "79,996",
      id: "93,078",
    },
    {
      // name: [team3, "Miriam Eric"],
      function: "PGIM India Mutual Fund",
      // review: (
      //   <SuiBox ml={-1.325}>
      //     <SuiBadgeDot size="small" badgeContent="positive" />
      //   </SuiBox>
      // ),
      // email: "miriam@user.com",
      employed: "7,500",
      id: "6,965",
    },
    {
      // name: [team3, "Miriam Eric"],
      function: "Baroda BNP Paribas Mutual Fund",
      employed: "1",
      id: "1",
    },
    {
      // name: [team3, "Miriam Eric"],
      function: "LIC Mutual Fund",
      employed: "0",
      id: "0",
    },
    {
      // name: [team3, "Miriam Eric"],
      function: "KFintech Total",
      employed: "1,85,62,811",
      id: "2,23,54,376",
    },
    {
      // name: [team3, "Miriam Eric"],
      function: "",
      employed: "CAMS",
      id: "",
    },
  ],
};
