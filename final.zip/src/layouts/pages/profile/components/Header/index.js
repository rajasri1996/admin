/**
=========================================================
* Soft UI Dashboard PRO React - v2.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/soft-ui-dashboard-pro-material-ui
* Copyright 2021 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// @mui material components
import Grid from "@mui/material/Grid";
// import Icon from "@mui/material/Icon";

// Soft UI Dashboard PRO React components
import SuiBox from "components/SuiBox";
import SuiTypography from "components/SuiTypography";

// Soft UI Dashboard PRO React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import MiniStatisticsCard from "examples/Cards/StatisticsCards/MiniStatisticsCard";
// import SalesTable from "examples/Tables/SalesTable";
// import ReportsBarChart from "examples/Charts/BarCharts/ReportsBarChart";
// import GradientLineChart from "examples/Charts/LineCharts/GradientLineChart";
// import Globe from "examples/Globe";

// Soft UI Dashboard PRO React base styles
// import typography from "assets/theme/base/typography";
import breakpoints from "assets/theme/base/breakpoints";

// Data
// import salesTableData from "layouts/dashboards/default/data/salesTableData";
// import reportsBarChartData from "layouts/dashboards/default/data/reportsBarChartData";
// import gradientLineChartData from "layouts/dashboards/default/data/gradientLineChartData";

function Default() {
  const { values } = breakpoints;
  // const { size } = typography;
  // const { chart, items } = reportsBarChartData;

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <SuiBox py={1}>
        <Grid container>
          <Grid item xs={12} lg={12}>
            <SuiBox mb={3} p={1}>
              <SuiTypography
                variant={window.innerWidth < values.sm ? "h3" : "h2"}
                textTransform="capitalize"
                fontWeight="bold"
                textAlign="center"
              >
                MONTHLY DASHBOARD
              </SuiTypography>
            </SuiBox>
            <h3>May</h3>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Investment" }}
                    count="Rs.53,000"
                    percentage={{ color: "success", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#1798A5;"
                  />
                </SuiBox>
                <MiniStatisticsCard
                  title={{ text: "Valuation" }}
                  count="Rs. 2,300"
                  percentage={{ color: "success", text: "" }}
                  icon={{ color: "", component: "" }}
                  // backgroundColor="#ffccff;"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Investment" }}
                    count="Rs.53,000"
                    percentage={{ color: "success", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#abebc6;"
                  />
                </SuiBox>
                <MiniStatisticsCard
                  title={{ text: "Valuation" }}
                  count="Rs. 2,300"
                  percentage={{ color: "success", text: "" }}
                  icon={{ color: "", component: "" }}
                  // backgroundColor="#e6f3ff;"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Div Paid" }}
                    count="Rs.3,462"
                    percentage={{ color: "error", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#ffccff;"
                  />
                </SuiBox>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Div Rein." }}
                    count="Rs.103,430"
                    percentage={{ color: "success", text: "" }}
                    icon={{
                      color: "",
                      component: "",
                    }}
                    // backgroundColor="#1798A5;"
                  />
                </SuiBox>
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total gain/Loss" }}
                    count="3,462"
                    percentage={{ color: "error", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#e6f3ff;"
                  />
                </SuiBox>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Abs Rtn./CAGR" }}
                    count="37.25%/18.22"
                    percentage={{ color: "success", text: "" }}
                    icon={{
                      color: "",
                      component: "",
                    }}
                    // backgroundColor="#ffccff;"
                  />
                </SuiBox>
              </Grid>
            </Grid>
            <h3>April</h3>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Investment" }}
                    count="Rs.53,000"
                    percentage={{ color: "success", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#1798A5;"
                  />
                </SuiBox>
                <MiniStatisticsCard
                  title={{ text: "Valuation" }}
                  count="Rs. 2,300"
                  percentage={{ color: "success", text: "" }}
                  icon={{ color: "", component: "" }}
                  // backgroundColor="#ffccff;"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Investment" }}
                    count="Rs.53,000"
                    percentage={{ color: "success", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#abebc6;"
                  />
                </SuiBox>
                <MiniStatisticsCard
                  title={{ text: "Valuation" }}
                  count="Rs. 2,300"
                  percentage={{ color: "success", text: "" }}
                  icon={{ color: "", component: "" }}
                  // backgroundColor="#e6f3ff;"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Div Paid" }}
                    count="Rs.3,462"
                    percentage={{ color: "error", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#ffccff;"
                  />
                </SuiBox>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Div Rein." }}
                    count="Rs.103,430"
                    percentage={{ color: "success", text: "" }}
                    icon={{
                      color: "",
                      component: "",
                    }}
                    // backgroundColor="#1798A5;"
                  />
                </SuiBox>
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total gain/Loss" }}
                    count="3,462"
                    percentage={{ color: "error", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#e6f3ff;"
                  />
                </SuiBox>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Abs Rtn./CAGR" }}
                    count="37.25%/18.22"
                    percentage={{ color: "success", text: "" }}
                    icon={{
                      color: "",
                      component: "",
                    }}
                    // backgroundColor="#ffccff;"
                  />
                </SuiBox>
              </Grid>
            </Grid>
            <h3>March</h3>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Investment" }}
                    count="Rs.53,000"
                    percentage={{ color: "success", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#1798A5;"
                  />
                </SuiBox>
                <MiniStatisticsCard
                  title={{ text: "Valuation" }}
                  count="Rs. 2,300"
                  percentage={{ color: "success", text: "" }}
                  icon={{ color: "", component: "" }}
                  // backgroundColor="#ffccff;"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Investment" }}
                    count="Rs.53,000"
                    percentage={{ color: "success", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#abebc6;"
                  />
                </SuiBox>
                <MiniStatisticsCard
                  title={{ text: "Valuation" }}
                  count="Rs. 2,300"
                  percentage={{ color: "success", text: "" }}
                  icon={{ color: "", component: "" }}
                  // backgroundColor="#e6f3ff;"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Div Paid" }}
                    count="Rs.3,462"
                    percentage={{ color: "error", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#ffccff;"
                  />
                </SuiBox>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total Div Rein." }}
                    count="Rs.103,430"
                    percentage={{ color: "success", text: "" }}
                    icon={{
                      color: "",
                      component: "",
                    }}
                    // backgroundColor="#1798A5;"
                  />
                </SuiBox>
              </Grid>
              <Grid item xs={12} sm={3}>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Total gain/Loss" }}
                    count="3,462"
                    percentage={{ color: "error", text: "" }}
                    icon={{ color: "", component: "" }}
                    // backgroundColor="#e6f3ff;"
                  />
                </SuiBox>
                <SuiBox mb={3}>
                  <MiniStatisticsCard
                    title={{ text: "Abs Rtn./CAGR" }}
                    count="37.25%/18.22"
                    percentage={{ color: "success", text: "" }}
                    icon={{
                      color: "",
                      component: "",
                    }}
                    // backgroundColor="#ffccff;"
                  />
                </SuiBox>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </SuiBox>
      <Footer />
    </DashboardLayout>
  );
}

export default Default;
